
let defaultId = 'P2P-Live-Web-Default-ID';

let theme_Index = "0";

let app_Mode = false;

let use_Local_Storage = true;

// let max_Child_Nodes = 4;