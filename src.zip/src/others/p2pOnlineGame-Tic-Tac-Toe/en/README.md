# P2P-Game-FiveOnline
Easily game &amp; chat built with PeerJS

### Next Version Plan:
+ combine files -> single version

## [Multi-Room Type -> https://aiksxd.github.io/P2PLiveIndex.html](https://aiksxd.github.io/P2PLiveIndex.html)
+ Instructions of files:
+ P2PLiveIndex.html serves as the website homepage (displaying rooms ready for live streaming and providing entry points)
+ P2PLiveHost.html & P2PLiveAudience.html are auxiliary pages placed in the same directory
### Instructions:
+ [For Audiences / Players]
1. Use browser to load the homepage(P2PLiveIndex.html) with available Internet, [if can't connect to the root node, directly enter and connect room ID]
2. After completing step one, you can view all active rooms, click it and click **auto Join**(or input room ID for directly jumping to room page)
3. after you enter the room, you can click **Join** to take part in gane as player.
+ [For Host]
1. Visit the homepage(P2PLiveIndex.html), [create pravite room or enter and connect a root ID]
2. Clicks **Create Room** and then **choose room type(FiveOnline)** in Option for **creating room**.
3. waiting for others join game and ready, you can **modify setting** or click **button of start** to start game